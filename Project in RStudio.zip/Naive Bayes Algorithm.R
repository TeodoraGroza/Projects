 fakeJob<-read.csv("C:/UBB anul III/sem II/Big Data/proiect_fakeJob/fakeJob.csv")
 
 install.packages("rsample")
 install.packages("caret")
 install.packages("corrplot")

 library(caret)
 library(rsample)
 library(corrplot)
 library(dplyr)
 
 fakeJob%>%
 select_if(is.numeric)%>%
 gather(metric, value )%>%
 ggplot(aes(value, fill=metric))+
 geom_density(show.legend = FALSE)+
 facet_wrap(~metric, scales = "free")
 
 fakeJob$fraudulent<-factor(fakeJob$fraudulent)
 
 fakeJob%>%
   filter(fraudulent=="1")%>%
   select_if(is.numeric)%>%
   cor()%>%
   corrplot::corrplot()
 
 fakeJob%>%
   filter(fraudulent=="0")%>%
   select_if(is.numeric)%>%
   cor()%>%
   corrplot::corrplot()
 
 fakeJob <- rename(fakeJob, job_function = function.)
 fakeJob<-fakeJob%>%
 mutate(fraudulent=factor(fraudulent), has_company_logo=factor(has_company_logo), has_questions=factor(has_questions), job_id=factor(job_id), telecommuting=factor(telecommuting))
 fakeJob<-fakeJob%>%
 mutate(title=factor(title), location=factor(location), department=factor(department), salary_range=factor(salary_range), company_profile=factor(company_profile), description=factor(description), requirements=factor(requirements), benefits=factor(benefits), employment_type=factor(employment_type), required_experience=factor(required_experience), required_education=factor(required_education), industry=factor(industry), job_function=factor(job_function))

 library(rsample)
 
 split<-initial_split(fakeJob, prop=0.7, strata = "fraudulent")
 fakeJob_train<-training(split)
 fakeJob_test<-testing(split)
 
 table(fakeJob_train$fraudulent)
 table(fakeJob_test$fraudulent)
 
 library(corrplot)
 library(dplyr)
 library(caret)
 
 features<-setdiff(names(fakeJob_train), "fraudulent")
 x<-fakeJob_train[,features]
 y<-fakeJob_train$fraudulent
 
 levels(y)<-make.names(levels(y))
 mod_nb1<-train(
     x = x, 
     y = y, 
     method = "nb", 
     trControl = trainControl(method = "cv", number = 10, classProbs = TRUE)
 )
 confusionMatrix(mod_nb1)
 
 install.packages("kernel")
 library(kernlab)
 search_grid<-expand.grid(usekernel=c(TRUE, FALSE), fL=0.5, adjust=seq(0,5,by=1))
 mod_nb2=train(x=x, y=y, method="nb", trControl = trainControl(method = "cv", number = 10, classProbs = TRUE), tuneGrid = search_grid,)
 confusionMatrix(mod_nb2)
 
 install.packages("magrittr")
 library(magrittr)
 library(dplyr)
 mod_nb2$results%>%
 top_n(5, wt=Accuracy)%>%
 arrange(desc(Accuracy))
 
 library(caret)
 pred<-predict(mod_nb2, fakeJob_test)
 levels(pred)<-levels(fakeJob_test$fraudulent)
 confusionMatrix(pred, fakeJob_test$fraudulent)
 
 library(pROC)
 predProb<-predict(mod_nb2, fakeJob_test, type = "prob")
 dataset<-data.frame(actual.fraudulent<-fakeJob_test$fraudulent, probability<-predProb[,1])
 roc.val<-roc(actual.fraudulent~probability, dataset)
 adf<-data.frame(x<-roc.val$specificities, y<-roc.val$sensitivities)
 colnames(adf)<-c("specificity", "sensitivity")
 ggplot(adf, aes(specificity, sensitivity))+geom_line()+scale_x_reverse()

 