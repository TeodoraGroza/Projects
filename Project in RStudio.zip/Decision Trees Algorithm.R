 fakeJob<-read.csv("C:/UBB anul III/sem II/Big Data/proiect_fakeJob/fakeJob.csv")
 library(dplyr)
 fakeJob<-subset(fakeJob, select = -job_id)
 fakeJob$location<-substr(fakeJob$location,1,2)
 fakeJob <- rename(fakeJob, job_function = function.)
 fakeJob$fraudulent[fakeJob$fraudulent=="0"]<-"No"
 fakeJob$fraudulent[fakeJob$fraudulent=="1"]<-"Yes"
 fakeJob$telecommuting[fakeJob$telecommuting=="0"]<-"No"
 fakeJob$telecommuting[fakeJob$telecommuting=="1"]<-"Yes"
 fakeJob$has_company_logo[fakeJob$has_company_logo=="0"]<-"No"
 fakeJob$has_company_logo[fakeJob$has_company_logo=="1"]<-"Yes"
 fakeJob$has_questions[fakeJob$has_questions=="0"]<-"No"
 fakeJob$has_questions[fakeJob$has_questions=="1"]<-"Yes"
 grouped_location <- fakeJob %>%
   group_by(location) %>%
   summarize(across(everything(), first))
 fakeJob <- fakeJob %>%
   mutate_all(~factor(.))
 library(rsample)
 split<-initial_split(grouped_location, prop = 0.7, strata = "fraudulent")
 fakeJob_train<-training(split)
 fakeJob_test<-testing(split) 
 fakeJob_test$title <- factor(fakeJob_test$title, levels = levels(fakeJob_train$title))
 fakeJob_test$location <- factor(fakeJob_test$location, levels = levels(fakeJob_train$location))
 fakeJob_test$department <- factor(fakeJob_test$department, levels = levels(fakeJob_train$department))
 fakeJob_test$salary_range <- factor(fakeJob_test$salary_range, levels = levels(fakeJob_train$salary_range))
 fakeJob_test$company_profile <- factor(fakeJob_test$company_profile, levels = levels(fakeJob_train$company_profile))
 fakeJob_test$description <- factor(fakeJob_test$description, levels = levels(fakeJob_train$description))
 fakeJob_test$requirements <- factor(fakeJob_test$requirements, levels = levels(fakeJob_train$requirements))
 fakeJob_test$benefits <- factor(fakeJob_test$benefits, levels = levels(fakeJob_train$benefits))
 fakeJob_test$industry <- factor(fakeJob_test$industry, levels = levels(fakeJob_train$industry))
 fakeJob_test$required_experience <- factor(fakeJob_test$required_experience, levels = levels(fakeJob_train$required_experience))
 fakeJob_test$required_education <- factor(fakeJob_test$required_education, levels = levels(fakeJob_train$required_education))
 fakeJob_test$job_function <- factor(fakeJob_test$job_function, levels = levels(fakeJob_train$job_function))
 fakeJob_test$employment_type<- factor(fakeJob_test$employment_type, levels = levels(fakeJob_train$employment_type))
 library(rpart)
 m1=rpart(formula = fraudulent~.,data = fakeJob_train, method = "class")
 pred_m1<-predict(m1, newdata = fakeJob_test, target="class")
 pred_m1<-as_tibble(pred_m1)%>%
  mutate(class=ifelse(No>=Yes,"No","Yes"))
 library(rpart.plot)
 rpart.plot(m1)
 library(caret)
 confusionMatrix(factor(pred_m1$class), factor(fakeJob_test$fraudulent))

 library(tree)
 m1_tree<-tree(fraudulent~.,data = fakeJob_train)
 m1_tree_gini<-tree(fraudulent~., data = fakeJob_train, split = "gini")
 print(m1_tree)
 print(m1_tree_gini)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               